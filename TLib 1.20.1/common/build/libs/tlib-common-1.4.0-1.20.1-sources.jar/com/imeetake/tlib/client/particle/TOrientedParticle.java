package com.imeetake.tlib.client.particle;

import net.minecraft.class_2394;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_638;

public abstract class TOrientedParticle<T extends class_2394> extends class_4003 {

    protected final class_4002 spriteSet;
    protected float scale; // В 1.20.1 это поле quadSize, но храним scale для API совместимости

    protected TOrientedParticle(class_638 level,
                                double x, double y, double z,
                                double velocityX, double velocityY, double velocityZ,
                                class_4002 spriteSet) {
        super(level, x, y, z, velocityX, velocityY, velocityZ);
        this.spriteSet = spriteSet;
        this.scale = 1.0f;
        this.field_3862 = false; // collidesWithWorld = false
    }

    @Override
    public class_3999 method_18122() {
        return class_3999.field_17829;
    }

    /**
     * CRITICAL: We override render to BYPASS the default billboard logic.
     * We do NOT calculate quaternions here. We strictly delegate to the subclass.
     */
    @Override
    public void method_3074(class_4588 vertexConsumer, class_4184 camera, float tickDelta) {
        // Do not call super.render() because that forces billboard rotation.
        this.buildGeometry(vertexConsumer, camera, tickDelta);
    }

    /**
     * Subclasses must implement this to define their own geometry (vertices),
     * completely ignoring standard camera orientation if they wish.
     */
    public abstract void buildGeometry(class_4588 vertexConsumer,
                                       class_4184 camera,
                                       float tickDelta);
}