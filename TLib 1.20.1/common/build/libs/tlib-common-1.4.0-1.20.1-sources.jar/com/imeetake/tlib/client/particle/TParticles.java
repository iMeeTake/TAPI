package com.imeetake.tlib.client.particle;

import dev.architectury.registry.client.particle.ParticleProviderRegistry;
import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import java.util.function.Function;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2400;
import net.minecraft.class_4002;
import net.minecraft.class_638;
import net.minecraft.class_707;

public class TParticles {

    /**
     * Исправленная версия.
     * 1. Принимает registry (чтобы регистрировать в ID мода, а не библиотеки).
     * 2. Использует new SimpleParticleType(false) {} (с фигурными скобками!),
     * чтобы обойти protected доступ.
     */
    public static RegistrySupplier<class_2400> simple(DeferredRegister<class_2396<?>> registry, String name) {
        return registry.register(name, () -> new class_2400(false) {});
    }

    // --- Остальные методы (можно оставить без изменений, они были рабочие) ---

    @FunctionalInterface
    public interface OrientedParticleFactory<T extends class_2394> {
        TOrientedParticle<T> create(class_638 level,
                                    double x, double y, double z,
                                    double velocityX, double velocityY, double velocityZ,
                                    class_4002 spriteSet);
    }

    public static <T extends class_2394> void registerOriented(
            RegistrySupplier<? extends class_2396<T>> type,
            OrientedParticleFactory<T> factory
    ) {
        ParticleProviderRegistry.register(type, spriteSet ->
                (parameters, level, x, y, z, dx, dy, dz) ->
                        factory.create(level, x, y, z, dx, dy, dz, spriteSet)
        );
    }

    public static <T extends class_2394> void register(
            RegistrySupplier<? extends class_2396<T>> type,
            Function<class_4002, class_707<T>> factoryFunction) {
        ParticleProviderRegistry.register(type, factoryFunction::apply);
    }

    public static <T extends class_2394> void registerSimple(
            RegistrySupplier<? extends class_2396<T>> type,
            TParticleFactoryProvider.ParticleCreator<T> creator
    ) {
        ParticleProviderRegistry.register(type, sprite -> new TParticleFactoryProvider<>(sprite, creator));
    }
}