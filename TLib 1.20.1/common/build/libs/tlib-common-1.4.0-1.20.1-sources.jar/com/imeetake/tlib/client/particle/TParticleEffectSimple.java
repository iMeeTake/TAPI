package com.imeetake.tlib.client.particle;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2540;
import net.minecraft.class_7923;

public class TParticleEffectSimple implements class_2394 {

    private final class_2396<TParticleEffectSimple> type;

    public TParticleEffectSimple(class_2396<TParticleEffectSimple> type) {
        this.type = type;
    }

    @Override
    public class_2396<?> method_10295() {
        return type;
    }

    @Override
    public void method_10294(class_2540 buf) {
    }

    @Override
    public String method_10293() {
        return class_7923.field_41180.method_10221(this.type).toString();
    }

    // Обязательное поле для ParticleOptions в 1.20.1
    public static final class_2394.class_2395<TParticleEffectSimple> DESERIALIZER = new class_2394.class_2395<>() {
        @Override
        public TParticleEffectSimple method_10296(class_2396<TParticleEffectSimple> type, StringReader reader) throws CommandSyntaxException {
            return new TParticleEffectSimple(type);
        }

        @Override
        public TParticleEffectSimple method_10297(class_2396<TParticleEffectSimple> type, class_2540 buf) {
            return new TParticleEffectSimple(type);
        }
    };
}