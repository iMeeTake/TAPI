package com.imeetake.tlib.client.particle;

import net.minecraft.class_2394;
import net.minecraft.class_310;

public class TClientParticles {

    public static void spawn(class_2394 effect, double x, double y, double z) {
        spawn(effect, x, y, z, 0, 0, 0);
    }

    public static void spawn(class_2394 effect, double x, double y, double z, double dx, double dy, double dz) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 != null) {
            client.field_1687.method_8406(effect, x, y, z, dx, dy, dz);
        }
    }
}