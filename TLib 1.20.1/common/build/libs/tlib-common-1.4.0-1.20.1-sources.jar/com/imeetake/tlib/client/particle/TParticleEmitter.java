package com.imeetake.tlib.client.particle;

import java.util.Random;
import net.minecraft.class_238;
import net.minecraft.class_2394;

public class TParticleEmitter {

    private static final Random RANDOM = new Random();

    public static void sphere(class_2394 effect, double cx, double cy, double cz, double radius, int count) {
        for (int i = 0; i < count; i++) {
            double costheta = 2 * RANDOM.nextDouble() - 1;
            double phi = 2 * Math.PI * RANDOM.nextDouble();
            double r = radius * Math.cbrt(RANDOM.nextDouble());
            double sinTheta = Math.sqrt(1 - costheta * costheta);

            double x = cx + r * sinTheta * Math.cos(phi);
            double y = cy + r * sinTheta * Math.sin(phi);
            double z = cz + r * costheta;

            TClientParticles.spawn(effect, x, y, z);
        }
    }

    public static void cube(class_2394 effect,
                            double minX, double minY, double minZ,
                            double maxX, double maxY, double maxZ,
                            int count) {
        for (int i = 0; i < count; i++) {
            double x = minX + RANDOM.nextDouble() * (maxX - minX);
            double y = minY + RANDOM.nextDouble() * (maxY - minY);
            double z = minZ + RANDOM.nextDouble() * (maxZ - minZ);

            TClientParticles.spawn(effect, x, y, z);
        }
    }

    public static void aabb(class_2394 effect, class_238 box, int count) {
        cube(effect,
                box.field_1323, box.field_1322, box.field_1321,
                box.field_1320, box.field_1325, box.field_1324,
                count);
    }
}