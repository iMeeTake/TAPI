package com.imeetake.tlib.client.particle;

import net.minecraft.class_2394;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

public class TParticleFactoryProvider<T extends class_2394> implements class_707<T> {

    private final class_4002 spriteSet;
    private final ParticleCreator<T> creator;

    public TParticleFactoryProvider(class_4002 spriteSet, ParticleCreator<T> creator) {
        this.spriteSet = spriteSet;
        this.creator = creator;
    }

    @Override
    public class_703 method_3090(T type, class_638 level, double x, double y, double z, double dx, double dy, double dz) {
        class_4003 particle = creator.create(level, x, y, z, dx, dy, dz);
        particle.method_18140(spriteSet);
        return particle;
    }

    @FunctionalInterface
    public interface ParticleCreator<T extends class_2394> {
        class_4003 create(class_638 level, double x, double y, double z, double dx, double dy, double dz);
    }
}