package com.imeetake.tlib.client.particle;

import net.minecraft.class_2394;
import net.minecraft.class_243;

public final class TParticleTargeting {

    private TParticleTargeting() {}

    public static class_243 direction(double sx, double sy, double sz, double tx, double ty, double tz) {
        class_243 diff = new class_243(tx - sx, ty - sy, tz - sz);
        double len = diff.method_1033();
        return len == 0 ? class_243.field_1353 : diff.method_1021(1.0 / len);
    }

    public static void spawnTowards(class_2394 effect,
                                    double sx, double sy, double sz,
                                    double tx, double ty, double tz,
                                    double speed) {
        class_243 dir = direction(sx, sy, sz, tx, ty, tz);
        TClientParticles.spawn(effect,
                sx, sy, sz,
                dir.field_1352 * speed, dir.field_1351 * speed, dir.field_1350 * speed
        );
    }

    public static void spawnAway(class_2394 effect,
                                 double sx, double sy, double sz,
                                 double tx, double ty, double tz,
                                 double speed) {
        class_243 dir = direction(sx, sy, sz, tx, ty, tz).method_1021(-1.0);
        TClientParticles.spawn(effect,
                sx, sy, sz,
                dir.field_1352 * speed, dir.field_1351 * speed, dir.field_1350 * speed
        );
    }

    public static void spawnUp(class_2394 effect,
                               double x, double y, double z,
                               double speed) {
        TClientParticles.spawn(effect,
                x, y, z,
                0, speed, 0
        );
    }

    public static void spawnDown(class_2394 effect,
                                 double x, double y, double z,
                                 double speed) {
        TClientParticles.spawn(effect,
                x, y, z,
                0, -speed, 0
        );
    }
}