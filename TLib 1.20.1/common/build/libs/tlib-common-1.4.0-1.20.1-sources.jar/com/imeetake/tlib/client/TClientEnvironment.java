package com.imeetake.tlib.client;

import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_746;

public class TClientEnvironment {

    public static class_638 getWorld() {
        return class_310.method_1551().field_1687;
    }

    public static boolean isRaining() {
        class_638 level = getWorld();
        return level != null && level.method_8419();
    }

    public static boolean isThundering() {
        class_638 level = getWorld();
        return level != null && level.method_8546();
    }

    public static float getRainStrength(float tickDelta) {
        class_638 level = getWorld();
        return level != null ? level.method_8430(tickDelta) : 0.0f; // getRainGradient -> getRainLevel
    }

    public static class_6880<class_1959> getCurrentBiome() {
        class_638 level = getWorld();
        class_746 player = class_310.method_1551().field_1724;

        if (level != null && player != null) {
            return level.method_23753(player.method_24515());
        }
        return null;
    }

    public static boolean isInOpenSky() {
        class_638 level = getWorld();
        class_746 player = class_310.method_1551().field_1724;

        if (level != null && player != null) {
            return level.method_8311(player.method_24515());
        }
        return false;
    }

    public static boolean isNight() {
        class_638 level = getWorld();

        if (level != null) {
            long timeOfDay = level.method_8532() % 24000L;
            return timeOfDay >= 13000L && timeOfDay <= 23000L;
        }
        return false;
    }

    public static boolean isColdBiome(class_6880<class_1959> entry, class_2338 pos) {
        if (entry == null) return false;
        class_1959 b = entry.comp_349();
        try {
            // 1.20.1 Mojang: Check for SNOW explicitly or cold temp
            return b.method_48162(pos) == class_1959.class_1963.field_9383
                    || b.method_8712() <= 0.15f;
        } catch (Throwable t) {
            return false;
        }
    }

    public static boolean isAridBiome(class_6880<class_1959> entry, class_2338 pos) {
        if (entry == null) return false;
        class_1959 b = entry.comp_349();
        try {
            return b.method_48162(pos) == class_1959.class_1963.field_9384;
        } catch (Throwable t) {
            return false;
        }
    }
}