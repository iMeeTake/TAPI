package com.imeetake.tlib.client.render;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_5498;

/**
 * Utility class for accessing client-side rendering state.
 * Architectury 1.20.1 (Mojang Mappings).
 */
public class TClientRenderUtils {

    public static class_4184 getCamera() {
        return class_310.method_1551().field_1773.method_19418();
    }

    public static class_243 getCameraPosition() {
        class_4184 camera = getCamera();
        return camera.method_19326();
    }

    public static class_243 getCameraLookVector() {
        class_4184 camera = getCamera();
        // Vec3.fromPolar logic equivalent
        float pitch = camera.method_19329();
        float yaw = camera.method_19330();
        float f = (float)Math.cos(-yaw * 0.017453292F - (float)Math.PI);
        float g = (float)Math.sin(-yaw * 0.017453292F - (float)Math.PI);
        float h = (float)-Math.cos(-pitch * 0.017453292F);
        float i = (float)Math.sin(-pitch * 0.017453292F);
        return new class_243((double)(g * h), (double)i, (double)(f * h));
    }

    public static boolean isFirstPerson() {
        return class_310.method_1551().field_1690.method_31044() == class_5498.field_26664;
    }

    public static boolean isThirdPersonBack() {
        return class_310.method_1551().field_1690.method_31044() == class_5498.field_26665;
    }

    public static boolean isThirdPersonFront() {
        return class_310.method_1551().field_1690.method_31044() == class_5498.field_26666;
    }

    public static boolean isHudVisible() {
        return !class_310.method_1551().field_1690.field_1842;
    }

    public static boolean isInGUI() {
        return class_310.method_1551().field_1755 != null;
    }

    public static double getFov() {
        // Mojang 1.20.1: options.fov() returns OptionInstance<Integer>
        return class_310.method_1551().field_1690.method_41808().method_41753();
    }
}